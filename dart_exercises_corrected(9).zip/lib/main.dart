// ─────────────────────────────────────────────────────────────────────────────
// MAIN — App entry point & home screen navigator
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'theme.dart';
import 'screens/ex1_grade_calculator.dart';
import 'screens/ex2_hof.dart';
import 'screens/ex3_lambda.dart';
import 'screens/ex4_oop.dart';

void main() {
  runApp(const DartExercisesApp());
}

class DartExercisesApp extends StatelessWidget {
  const DartExercisesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dart/Flutter Exercises — Chap 1 & 2',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: const HomeScreen(),
    );
  }
}

// ── Home / Navigation hub ──────────────────────────────────────────────────────
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // App header
              const SizedBox(height: 10),
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppTheme.highlight.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppTheme.highlight.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.code, color: AppTheme.highlight, size: 28),
                ),
                const SizedBox(width: 14),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Dart / Flutter Exercises',
                          style: TextStyle(color: AppTheme.textPrimary,
                              fontWeight: FontWeight.w900, fontSize: 22)),
                      Text('Chapter 1 & 2 — Combined',
                          style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                    ],
                  ),
                ),
              ]),
              const SizedBox(height: 8),
              const Text(
                'OOP · Lambda Functions · Higher-Order Functions · Closures · Inheritance · Polymorphism',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 11),
              ),
              const SizedBox(height: 28),

              // Exercise cards
              _exerciseCard(
                context,
                number: '01',
                chapter: 'Chap 1 + 2',
                title: 'Student Grade Calculator',
                description:
                    'Full-featured grade management system. Demonstrates OOP (Student, Grade, GradeBook classes), '
                    'lambda functions, and HOF pipeline (map, filter, reduce, fold) applied to real grade data. '
                    'Includes weighted averages, sorting, filtering, and analytics.',
                concepts: ['OOP', 'Lambda', 'map', 'filter', 'fold', 'reduce', 'Encapsulation', 'GUI'],
                color: AppTheme.highlight,
                screen: const GradeCalculatorScreen(),
                icon: Icons.school,
              ),
              const SizedBox(height: 14),

              _exerciseCard(
                context,
                number: '02',
                chapter: 'Chap 2',
                title: 'Higher-Order Functions',
                description:
                    'Interactive explorer for all major HOF patterns in Dart: map, filter/where, reduce, fold, '
                    'every, any, sort, take/skip. Also covers functions as first-class values, currying '
                    '(function factories), zipWith, and applyNTimes (composition).',
                concepts: ['map', 'filter', 'reduce', 'fold', 'every', 'any', 'Currying', 'First-class Functions'],
                color: AppTheme.green,
                screen: const HOFScreen(),
                icon: Icons.functions,
              ),
              const SizedBox(height: 14),

              _exerciseCard(
                context,
                number: '03',
                chapter: 'Chap 2',
                title: 'Lambda Functions & Closures',
                description:
                    'Comprehensive guide to anonymous functions and closures in Dart. '
                    'Covers arrow syntax, variable capture, factory functions (currying), typedef, '
                    'IIFE, closures as state containers, memoization, and lambda pipelines.',
                concepts: ['Anonymous Fn', 'Arrow Syntax', 'Closures', 'Capture', 'Currying', 'IIFE', 'typedef', 'Memoize'],
                color: AppTheme.gold,
                screen: const LambdaScreen(),
                icon: Icons.bolt,
              ),
              const SizedBox(height: 14),

              _exerciseCard(
                context,
                number: '04',
                chapter: 'Chap 2',
                title: 'OOP Deep Dive',
                description:
                    'University personnel management system demonstrating the full OOP hierarchy: '
                    'abstract classes, inheritance chains, method overriding, polymorphic dispatch, '
                    'mixins (Describable), type checking (is/as/whereType), and OOP+HOF integration.',
                concepts: ['abstract', 'extends', 'override', 'Polymorphism', 'Mixin', 'is/as', 'whereType', 'Inheritance'],
                color: const Color(0xFF9C6FDE),
                screen: const OOPScreen(),
                icon: Icons.account_tree,
              ),
              const SizedBox(height: 28),

              // Concept quick-reference footer
              _conceptReference(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _exerciseCard(
    BuildContext context, {
    required String number,
    required String chapter,
    required String title,
    required String description,
    required List<String> concepts,
    required Color color,
    required Widget screen,
    required IconData icon,
  }) {
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => screen)),
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.cardBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Card header
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: color.withOpacity(0.08),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(17)),
                border: Border(bottom: BorderSide(color: color.withOpacity(0.2))),
              ),
              child: Row(
                children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(number, style: TextStyle(
                          color: color, fontWeight: FontWeight.w900, fontSize: 18)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(chapter, style: TextStyle(
                                color: color, fontSize: 10, fontWeight: FontWeight.w700)),
                          ),
                          const SizedBox(width: 6),
                          Icon(icon, color: color, size: 14),
                        ]),
                        const SizedBox(height: 2),
                        Text(title, style: const TextStyle(
                            color: AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 16)),
                      ],
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios, color: color, size: 16),
                ],
              ),
            ),
            // Card body
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(description, style: const TextStyle(
                      color: AppTheme.textSecondary, fontSize: 12, height: 1.5)),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6, runSpacing: 4,
                    children: concepts.map((c) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: color.withOpacity(0.25)),
                      ),
                      child: Text(c, style: TextStyle(
                          color: color, fontSize: 10, fontWeight: FontWeight.w600)),
                    )).toList(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _conceptReference() {
    final categories = [
      {
        'label': 'Chapter 1 Concepts',
        'color': AppTheme.highlight,
        'items': ['Variables & Types', 'Control Flow', 'Functions', 'Lists & Maps',
                  'Classes (basic)', 'Constructors', 'Getters/Setters', 'Null Safety'],
      },
      {
        'label': 'Chapter 2 Concepts',
        'color': AppTheme.green,
        'items': ['Lambda / Anonymous Fn', 'Arrow Syntax', 'HOF: map/filter/fold', 'Closures',
                  'Currying', 'typedef', 'Abstract Classes', 'Inheritance',
                  'Polymorphism', 'Mixins', 'Generics', 'is/as/whereType'],
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Concept Index', style: TextStyle(
            color: AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 14)),
        const SizedBox(height: 10),
        ...categories.map((cat) {
          final color = cat['color'] as Color;
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.06),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.2)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(cat['label'] as String, style: TextStyle(
                  color: color, fontWeight: FontWeight.w700, fontSize: 12)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6, runSpacing: 4,
                children: (cat['items'] as List<String>).map((item) =>
                  Text('· $item', style: const TextStyle(
                      color: AppTheme.textSecondary, fontSize: 11))).toList(),
              ),
            ]),
          );
        }),
      ],
    );
  }
}
