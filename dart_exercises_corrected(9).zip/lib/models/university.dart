// ─────────────────────────────────────────────────────────────────────────────
// CHAPTER 2 — Exercise 4: OOP Deep Dive
// Demonstrates: abstract classes, inheritance, polymorphism,
//               interfaces (via abstract), method overriding, mixins
// Context: A university Staff/Personnel hierarchy
// ─────────────────────────────────────────────────────────────────────────────

// ── Mixin: Describable ────────────────────────────────────────────────────────
mixin Describable {
  String describe();
  String get shortDescription => describe().split('\n').first;
}

// ── Abstract base class ───────────────────────────────────────────────────────
abstract class UniversityMember with Describable {
  final String id;
  final String name;
  final String email;
  final int yearJoined;

  UniversityMember({
    required this.id,
    required this.name,
    required this.email,
    required this.yearJoined,
  });

  // Abstract method — must be overridden
  String get role;
  double get monthlyPay;
  String get department;

  // Concrete method available to all subclasses
  int get yearsActive => DateTime.now().year - yearJoined;

  // Polymorphic method
  String greet() => 'Hello, I am $name, a $role at the university.';

  @override
  String toString() => '$role: $name (ID: $id)';
}

// ── Abstract subclass: AcademicMember ────────────────────────────────────────
abstract class AcademicMember extends UniversityMember {
  final String faculty;
  final List<String> courses;

  AcademicMember({
    required super.id,
    required super.name,
    required super.email,
    required super.yearJoined,
    required this.faculty,
    required this.courses,
  });

  // Abstract method for academics
  int get maxCoursesPerSemester;

  bool get isOverloaded => courses.length > maxCoursesPerSemester;

  @override
  String get department => faculty;
}

// ── Concrete: Professor ───────────────────────────────────────────────────────
class Professor extends AcademicMember {
  final String rank; // 'Assistant', 'Associate', 'Full'
  final double baseSalary;
  final List<String> researchTopics;

  Professor({
    required super.id,
    required super.name,
    required super.email,
    required super.yearJoined,
    required super.faculty,
    required super.courses,
    required this.rank,
    required this.baseSalary,
    required this.researchTopics,
  });

  @override
  String get role => '$rank Professor';

  @override
  double get monthlyPay => baseSalary / 12;

  @override
  int get maxCoursesPerSemester => 4;

  // Override greet polymorphically
  @override
  String greet() =>
      'Good day! I am Prof. $name, $rank Professor in $faculty.';

  @override
  String describe() =>
      '$role: $name\n'
      'Faculty: $faculty\n'
      'Courses: ${courses.join(", ")}\n'
      'Research: ${researchTopics.join(", ")}\n'
      'Monthly Pay: \$${monthlyPay.toStringAsFixed(2)}\n'
      'Years Active: $yearsActive';
}

// ── Concrete: TeachingAssistant ────────────────────────────────────────────────
class TeachingAssistant extends AcademicMember {
  final String supervisorId;
  final double hourlyRate;
  final int hoursPerWeek;

  TeachingAssistant({
    required super.id,
    required super.name,
    required super.email,
    required super.yearJoined,
    required super.faculty,
    required super.courses,
    required this.supervisorId,
    required this.hourlyRate,
    required this.hoursPerWeek,
  });

  @override
  String get role => 'Teaching Assistant';

  @override
  double get monthlyPay => hourlyRate * hoursPerWeek * 4.33;

  @override
  int get maxCoursesPerSemester => 2;

  @override
  String describe() =>
      '$role: $name\n'
      'Faculty: $faculty\n'
      'Courses: ${courses.join(", ")}\n'
      'Hours/Week: $hoursPerWeek @ \$$hourlyRate/hr\n'
      'Monthly Pay: \$${monthlyPay.toStringAsFixed(2)}\n'
      'Years Active: $yearsActive';
}

// ── Abstract subclass: AdministrativeStaff ───────────────────────────────────
abstract class AdministrativeStaff extends UniversityMember {
  final String office;

  AdministrativeStaff({
    required super.id,
    required super.name,
    required super.email,
    required super.yearJoined,
    required this.office,
  });

  @override
  String get department => office;

  List<String> get responsibilities;
}

// ── Concrete: Registrar ──────────────────────────────────────────────────────
class Registrar extends AdministrativeStaff {
  final double annualSalary;
  @override
  final List<String> responsibilities;

  Registrar({
    required super.id,
    required super.name,
    required super.email,
    required super.yearJoined,
    required super.office,
    required this.annualSalary,
    required this.responsibilities,
  });

  @override
  String get role => 'Registrar';

  @override
  double get monthlyPay => annualSalary / 12;

  @override
  String greet() => 'Welcome to the Registrar\'s Office. I am $name.';

  @override
  String describe() =>
      '$role: $name\n'
      'Office: $office\n'
      'Responsibilities: ${responsibilities.join(", ")}\n'
      'Monthly Pay: \$${monthlyPay.toStringAsFixed(2)}\n'
      'Years Active: $yearsActive';
}

// ── Concrete: ITStaff ─────────────────────────────────────────────────────────
class ITStaff extends AdministrativeStaff {
  final String specialization;
  final double hourlyRate;
  final int hoursPerWeek;
  @override
  final List<String> responsibilities;

  ITStaff({
    required super.id,
    required super.name,
    required super.email,
    required super.yearJoined,
    required super.office,
    required this.specialization,
    required this.hourlyRate,
    required this.hoursPerWeek,
    required this.responsibilities,
  });

  @override
  String get role => 'IT Staff ($specialization)';

  @override
  double get monthlyPay => hourlyRate * hoursPerWeek * 4.33;

  @override
  String describe() =>
      '$role: $name\n'
      'Office: $office\n'
      'Specialization: $specialization\n'
      'Monthly Pay: \$${monthlyPay.toStringAsFixed(2)}\n'
      'Years Active: $yearsActive';
}

// ── Factory / Registry ────────────────────────────────────────────────────────
class UniversityRegistry {
  final List<UniversityMember> _members = [];

  void add(UniversityMember m) => _members.add(m);

  List<UniversityMember> get all => List.unmodifiable(_members);

  // HOF: polymorphic filter by runtime type
  List<T> getByType<T extends UniversityMember>() =>
      _members.whereType<T>().toList();

  // HOF: total payroll using fold
  double get totalMonthlyPayroll =>
      _members.fold(0, (sum, m) => sum + m.monthlyPay);

  // Polymorphism demo: greet all members
  List<String> greetAll() => _members.map((m) => m.greet()).toList();

  // HOF: sort by pay
  List<UniversityMember> get sortedByPay =>
      [..._members]..sort((a, b) => b.monthlyPay.compareTo(a.monthlyPay));
}

// ── Sample data factory ────────────────────────────────────────────────────────
UniversityRegistry buildSampleRegistry() {
  final reg = UniversityRegistry();

  reg.add(Professor(
    id: 'P001', name: 'Dr. Alice Mbeki', email: 'ambeki@uni.edu',
    yearJoined: 2010, faculty: 'Computer Science',
    courses: ['Algorithms', 'Data Structures', 'AI'],
    rank: 'Full', baseSalary: 96000,
    researchTopics: ['Machine Learning', 'Graph Theory'],
  ));

  reg.add(Professor(
    id: 'P002', name: 'Dr. Bruno Faria', email: 'bfaria@uni.edu',
    yearJoined: 2018, faculty: 'Mathematics',
    courses: ['Calculus I', 'Linear Algebra'],
    rank: 'Assistant', baseSalary: 72000,
    researchTopics: ['Topology', 'Number Theory'],
  ));

  reg.add(TeachingAssistant(
    id: 'T001', name: 'Chloe Dupont', email: 'cdupont@uni.edu',
    yearJoined: 2022, faculty: 'Computer Science',
    courses: ['Intro to Programming'],
    supervisorId: 'P001', hourlyRate: 18, hoursPerWeek: 20,
  ));

  reg.add(Registrar(
    id: 'A001', name: 'David Osei', email: 'dosei@uni.edu',
    yearJoined: 2015, office: 'Academic Affairs',
    annualSalary: 54000,
    responsibilities: ['Student Records', 'Enrollment', 'Transcripts'],
  ));

  reg.add(ITStaff(
    id: 'A002', name: 'Elena Kovač', email: 'ekovac@uni.edu',
    yearJoined: 2019, office: 'IT Department',
    specialization: 'Network Security',
    hourlyRate: 25, hoursPerWeek: 40,
    responsibilities: ['Network', 'Cybersecurity', 'Servers'],
  ));

  return reg;
}
